self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7e8698904a9f9ef56d3d",
    "url": "app-menu-main@1.1.0.js"
  },
  {
    "revision": "3242dfcb7cd55c4614122eb7f526427d",
    "url": "index.html"
  },
  {
    "revision": "7e8698904a9f9ef56d3d",
    "url": "static/css/main.857adb16.css"
  }
]);
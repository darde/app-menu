self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "85115e5f116ba86c8287",
    "url": "app-menu-main@1.1.0.js"
  },
  {
    "revision": "3242dfcb7cd55c4614122eb7f526427d",
    "url": "index.html"
  },
  {
    "revision": "85115e5f116ba86c8287",
    "url": "static/css/main.857adb16.css"
  }
]);
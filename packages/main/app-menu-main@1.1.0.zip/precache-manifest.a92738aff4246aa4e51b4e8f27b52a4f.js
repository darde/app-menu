self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5ac083461e0860fe9f54",
    "url": "app-menu-main@1.1.0.js"
  },
  {
    "revision": "3242dfcb7cd55c4614122eb7f526427d",
    "url": "index.html"
  },
  {
    "revision": "5ac083461e0860fe9f54",
    "url": "static/css/main.857adb16.css"
  }
]);